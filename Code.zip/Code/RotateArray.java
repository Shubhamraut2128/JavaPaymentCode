import java.lang.reflect.Array;
import java.util.Arrays;

public class RotateArray {
    
     public static void rotateArray(int[]arr,int k){
        int n =arr.length;

        int [] result =new int[n];
     

     for(int i = 0; i < n; i++) {
        result[(i + k) % n] = arr[i];
    }   

      for (int i = 0; i < n; i++) {
        arr[i] = result[i];
      }
    }
    
     public static void main(String[]args){
    
        int [] arr={1,2,3,4,5};
        int k=2;
         
        
        System.out.println("original"+Arrays.toString(arr));
        rotateArray(arr ,k);
        System.out.println("rotate "+Arrays.toString(arr));

    }
 }
