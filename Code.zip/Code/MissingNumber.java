public class MissingNumber {
    
    public static void main(String []args){

        int arr []={10,20,30,40,60,70,80,90,100};
          
        int n=10;
        int first=10;
        int last=100;
         
        int expectedNo = n*(first+last)/2;

        int actualNo=0;

         for(int num : arr){
            actualNo += num;
         }
         
         int missing = expectedNo - actualNo;
         System.out.println(missing);
    }
}
