import java.util.Arrays;

public class ArraySort {
     
    public static void main(String []args){
        
        int arr[] ={6,8,2,9,1,3,4};

          Arrays.sort(arr);

          for(int num : arr){
            System.out.print(num+" ");
          }
    }
}
