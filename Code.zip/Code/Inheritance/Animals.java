package Inheritance;

public class Animals {
    void eat() {
        System.out.println("Eating the food");
    }
}

class Dog extends Animals {
    void bark() {
        System.out.println("Barking like a dog");
    }
}

class Cat extends Dog {
    void meow() {
        System.out.println("Cat sound is meow");
    }

    public static void main(String[] args) {
        Cat cat = new Cat();
        cat.eat();   // from Animals
        cat.bark();  // from Dog
        cat.meow();  // from Cat
    }
}
