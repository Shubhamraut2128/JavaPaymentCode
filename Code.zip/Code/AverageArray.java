public class AverageArray {
    
    public static void main(String[] args) {
        
        int arrs[]={ 20,44,31,50,55,30,22,30};
          
      float avg ,sum =0;

        int length = arrs.length;

        for(int arr :arrs){
            sum =sum+arr;
        }
        avg  =sum/length;

        System.out.println("average ="+avg);
    }
}
