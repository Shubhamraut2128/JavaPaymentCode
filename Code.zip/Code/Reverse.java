public class Reverse {
      
    public static void main(String []args){

        String str ="Atom";
        String reversed ="";

        for(int i =0;i<str.length();i++){

            reversed =str.charAt(i)+reversed;
        }
        System.out.println("String reversed: "+reversed);
    }
}
