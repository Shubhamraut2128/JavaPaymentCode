public class PrimeCheck {
    
    public static void main(String[]args){
        int num=8;
        boolean isPrime=true;

        if(num <=1){
            isPrime =false;
        }

      for(int i=2;i*i<=num ;i++){
         if(num %1 == 0){
            isPrime =false;
            break;
         }
      }
      System.out.println(num+(isPrime ? "is Prime":"is not Prime"));
    }
}
