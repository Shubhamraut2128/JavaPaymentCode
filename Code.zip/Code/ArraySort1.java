import java.util.Arrays;

public class ArraySort1 {
     
    public static void main(String []args){

        int arr [] ={80,50,40,20,90,10,30};
       Arrays.sort(arr);

       for(int arrs:arr){
        System.out.print(arrs+" ");
       }
        
    }
}
