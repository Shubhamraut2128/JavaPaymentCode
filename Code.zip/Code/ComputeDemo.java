import java.util.HashMap;
import java.util.Map;

public class ComputeDemo {
    
    public static void main(String[]args){
        String arr[] ={"sHUBHAM","sAGAR","Amit","Pritam","Mangesh"};

        Map<String,Integer> m = new HashMap<>();

       for(String name :arr){
        m.compute(name, (key ,value) ->
        (value == null) ? 1: value+1);
       }
        System.out.println(m);
    }
}
