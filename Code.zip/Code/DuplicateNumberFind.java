public class DuplicateNumberFind {
    
    public static void main(String[]args){

        int arr[] ={90,40,30,50,20,40,10};

        for(int i=0;i<arr.length;i++){
            for(int j=i+1;j<arr.length;j++){
                
                if(arr[i]==arr[j]){
                    System.out.println("Find the duplicate Number = " +arr[i]);
                }
            }
        }
    }
}
