public class FactorialExample {
     
    public static void main(String[]args){

        int fact =1;
        int n=6;

        for(int i=1;i<=n;i++){
            
            fact =fact*n;
        }
        System.out.println("Factorial number = "+fact);
    }
}
