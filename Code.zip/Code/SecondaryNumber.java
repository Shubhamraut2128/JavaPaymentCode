import java.util.Arrays;

public class SecondaryNumber{
    
    public static void main(String[]args){

        int[] arr ={80,60,55,90,20,50,30,77,10};

        Arrays.sort(arr);

          int secondLargestNumber = arr[arr.length-2];

          System.out.println("second largest number : "+secondLargestNumber);
    }
}
