public class PalindromeLogic {
    
    public static void main(String []args){

        int num=121;
        String original =Integer.toString(num);

        String reversed =new StringBuilder(original).reverse().toString();

        if(original .equals(reversed)){
            System.out.println(num + "is a palindrom");
        }else{
            System.out.println(num + "Not a palindrom");
        }
    }
}
