import React, { useEffect, useState } from 'react';

function App() {
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetch('/api/message') // auto uses proxy
      .then(res => res.json())
      .then(data => {
        setMessage(data.message || 'Connected, but no message');
      })
      .catch(err => {
        console.error('Error connecting to backend:', err);
        setMessage('Failed to connect to backend');
      });
  }, []);

  return (
    <div style={{ textAlign: 'center', marginTop: '100px' }}>
      <h1>{message}</h1>
    </div>
  );
}

export default App;
