const express = require("express")
const router  = express.Router();

const {
    getUsers ,
    getUserById,
    createUser,
    updateUser,
    deleteUser,
}  = require("./controller/userController");

router.get("/",getUsers);
router.get("/",getUserById);
router.post("/",createUser);
router.put("/:id",updateUser);
router.delete("/:id".deleteUser);

// const { register, login, logout } = require('../controllers/userController');

// router.post('/register', register);
// router.post('/login', login);
// router.post('/logout', logout);
module.exports =router;