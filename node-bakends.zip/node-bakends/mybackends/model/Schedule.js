
const mongoose = require("mongose");

const scheduleShema = new mongoose.Schema({

   title:String,
    date:Date,
    status:String,
},{timestamp:true});

module.exports = mongoose.scheduleShema("Schedule", scheduleSchema);