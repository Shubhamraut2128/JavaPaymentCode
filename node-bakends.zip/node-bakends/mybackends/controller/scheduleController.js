
const Schedule = require('../model/Schedule');

//get all data
exports.getAll =async (req,res)=>{
const item = await Schedule.find();
 res.json(item);
}

//get by id 
exports.getById = async(req,res)=>{
const item = await Schedule.findById(res.params.id);
if(!item)
    return res.status(404).json({message:"Not found"});
res.json(item);
}

//post meathod to crratd the data
exports.create= async(req,res)=>{
const item =new Schedule(req.body);
await item.save();
res.status(201).json(item);

}

//put method 
exports.update = async(req,res)=>{
 const item =await Schedule.findByIdAndUpdate(req.params.id,req.body,{new:true});
if(!item)
    return res.status(404).json({message:"Not Found"});
   res.json(item);
}

//delete

exports.delete =async(req,res)=>{
const item = await Schedule.deleteById(req.params.id);
 if(item)
    return res.status(404).json({message:"Not Found"});
res.json(item);
}