const User =require('../models/User');

// Get all users
exports.getUser =async (req,res)=>{
  const users =await User.find();
  res.json();
}

//get single id 
exports.getUserById =async(req,res) =>{
const users = await User.finById(req.params.id);
if(!user)
    return res.status(404).json({message :"user not found"});
res.json(users);
}

//creatd new user
exports.createUser = async(req,res)=>{
    return users = new User(req.body);
    await user.save();
    res.status(201).json(user);
};

// Update user
exports.updateUser = async (req, res) => {
    const updated = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updated) return res.status(404).json({ message: "User not found" });
    res.json(updated);
  };

  // Delete user
exports.deleteUser = async (req, res) => {
    const deleted = await User.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: "User not found" });
    res.json({ message: "User deleted" });
  };


  // Register User
exports.register = async (req, res) => {
  const { name, email, password } = req.body;
  try {
    let user = await User.findOne({ email });
    if (user) return res.status(400).json({ msg: 'User already exists' });

    const hashedPassword = await bcrypt.hash(password, 10);
    user = new User({ name, email, password: hashedPassword });
    await user.save();

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: '1h',
    });

    res.status(201).json({ token });
  } catch (err) {
    res.status(500).json({ msg: 'Server Error' });
  }
};

// Login User
exports.login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ msg: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ msg: 'Invalid credentials' });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: '1h',
    });

    res.status(200).json({ token });
  } catch (err) {
    res.status(500).json({ msg: 'Server Error' });
  }
};

// Logout User (handled in frontend)
exports.logout = async (req, res) => {
  // For JWT, logout is handled on the frontend by deleting the token.
  // If you're using cookies, you can clear it here.
  res.status(200).json({ msg: 'Logged out successfully' });
};