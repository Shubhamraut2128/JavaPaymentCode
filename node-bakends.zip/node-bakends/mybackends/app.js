const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const cors = require("cors");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// DB config
require("./config/db")();

// Routes
app.use("/api/users", require("./routes/userRoutes"));
app.use("/api/schedules", require("./routes/scheduleRoutes"));
app.use("/api/requests", require("./routes/requestRoutes"));
app.use("/api/reports", require("./routes/reportRoutes"));
app.use("/api/documents", require("./routes/documentRoutes"));
app.use("/api/dashboard", require("./routes/dashboardRoutes"));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
