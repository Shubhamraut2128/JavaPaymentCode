import React, { useState } from 'react';
import axios from 'axios';

const CreateOrderForm = () => {
  // State to manage form inputs
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phno, setPhno] = useState('');
  const [course, setCourse] = useState('');
  const [amount, setAmount] = useState('');
  const [orderResponse, setOrderResponse] = useState(null);

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const orderData = {
      name,
      email,
      phno,
      course,
      amout: amount,
    };

    try {
      // Send data to the backend
      const response = await axios.post('http://localhost:8080/api/payment/createOrder', orderData);
      setOrderResponse(response.data);
    } catch (error) {
      console.error('Error creating order:', error);
    }
  };

  return (
    <div>
      <h2>Create Order</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name: </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Email: </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Phone Number: </label>
          <input
            type="text"
            value={phno}
            onChange={(e) => setPhno(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Course: </label>
          <input
            type="text"
            value={course}
            onChange={(e) => setCourse(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Amount: </label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </div>
        <button type="submit">Create Order</button>
      </form>

      {orderResponse && (
        <div>
          <h3>Order Created Successfully!</h3>
          <p>Order ID: {orderResponse.orderId}</p>
          <p>Razorpay Order ID: {orderResponse.razorpayOrderId}</p>
        </div>
      )}
    </div>
  );
};

export default CreateOrderForm;
